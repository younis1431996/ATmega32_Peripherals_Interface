# ATmega32_Peripherals_Interface
 GPIO, pin change interrupt, timers, wave generator, PWM, frequncy measurement, ADC and sommunication protocols interfacing.ment interfac
